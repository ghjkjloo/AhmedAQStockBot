
import os
import requests
import datetime
import random

TOKEN = os.getenv("TELEGRAM_TOKEN")
USER = os.getenv("TELEGRAM_USER", "@AHMEDAL603")

def send_message(text):
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    data = {
        "chat_id": USER,
        "text": text
    }
    requests.post(url, data=data)

def get_mock_recommendation():
    tickers = ["GME", "AMC", "NVDA", "TSLA", "AAPL"]
    selected = random.choice(tickers)
    price = round(random.uniform(2, 15), 2)
    target = round(price * random.uniform(1.5, 2.2), 2)
    return f"🚀 توصية اليوم ({datetime.date.today()}):\nاشترِ {selected} بسعر ${price}, الهدف: ${target}"

if __name__ == "__main__":
    send_message(get_mock_recommendation())
