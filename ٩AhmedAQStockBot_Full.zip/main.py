
import requests
import time

BOT_TOKEN = "8329909736:AAGprfVQGWiptzSckSMFygC7tJSp4uhNdw"
CHAT_ID = "@AHMEDAL603"
MESSAGE = "📈 توصية اليوم: شراء LICN بسعر 3.90$، الهدف 5.00$"

def send_telegram_message():
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    data = {"chat_id": CHAT_ID, "text": MESSAGE}
    response = requests.post(url, data=data)
    print("✅ Message sent:", response.status_code)

if __name__ == "__main__":
    while True:
        send_telegram_message()
        time.sleep(86400)  # كل 24 ساعة
